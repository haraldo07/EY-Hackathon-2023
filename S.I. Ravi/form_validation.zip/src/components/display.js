function Display(props)
{
    return(<h1>{props.content}</h1>);
}

export default Display;